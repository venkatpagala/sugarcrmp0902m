<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /advent/projects/wesat/vtiger_crm/sugarcrm/modules/Home/language/en_us.lang.php,v 1.5 2005/03/04 15:18:47 jack Exp $
 * Description:  Defines the English language pack 
 ********************************************************************************/
 
$mod_strings = Array(
'LBL_NEW_FORM_TITLE'=>'Liên hệ mới',
'LBL_FIRST_NAME'=>'Họ đệm',
'LBL_LAST_NAME'=>'Tên',
'LBL_LIST_LAST_NAME'=>'Tên',
'LBL_ACCOUNT_NAME'=>'Tên Tài khoản',
'LBL_LIST_ACCOUNT_NAME'=>'Tên Tài khoản',
'LBL_PHONE'=>'Điện thoại',
'LBL_EMAIL_ADDRESS'=>'Email',
'LBL_TOTAL'=>'Tổng số  ',

'LBL_MY_HOME'=>'Trang chủ',
'LBL_MODIFIED_TIME'=>'Ngày cập nhật',
'LBL_LOGIN_ID'=>'Mã',
'LBL_MODIFIED_BY'=>'Cập nhật bởi',
'LBL_TYPE'=>'Loại',

'LBL_PIPELINE_FORM_TITLE'=>'Nguồn hàng',

'ERR_ONE_CHAR'=>'Hãy nhập một số hoặc chữ số để tìm kiếm ...',

'LBL_OPEN_TASKS'=>'Các công việc chung',

'LBL_LEADS_BY_SOURCE'=>'Đầu mối theo Nguồn',
'LBL_LEADS_BY_STATUS'=>'Đầu mối theo Trạng thái',

'LBL_UPCOMING_EVENTS'=>'Các hoạt động sắp tới',
'LBL_PENDING_EVENTS'=>'Các hoạt động chưa tiến hành',
'LBL_SINGLE_PENDING_EVENT'=>'Sự kiện trong vòng 10 ngày',
'LBL_MULTIPLE_PENDING_EVENTS'=>'Sự kiện trong vòng 10 ngày',

'recordsforuser'=>'Báo cáo cho',

'Today'=>'Hôm nay',
'This Week'=>'Tuần này',
'This Month'=>'Tháng này',
'This Year'=>'Năm nay',
'Last Week'=>'Tuần trước',
'Last 2 Days'=>'2 ngày trước',
'Last Ten Days'=>'10 ngày trước',

// Added/Updated for vtiger CRM 5.0.4                                                                                                                              
'TITLE_AJAX_CSS_POPUP_CHAT'=>'Ajax Css-Popup chat',
'User List'=>'Danh sách người dùng',

);

?>
