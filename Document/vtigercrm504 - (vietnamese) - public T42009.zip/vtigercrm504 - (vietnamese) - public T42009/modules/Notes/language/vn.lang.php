<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * $Header: /advent/projects/wesat/vtiger_crm/sugarcrm/modules/Notes/language/en_us.lang.php,v 1.10 2005/03/28 06:33:37 rank Exp $
 * Description:  Defines the English language pack for the Account module.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

$mod_strings = Array(
'LBL_MODULE_NAME'=>'Ghi chú',
'LBL_MODULE_TITLE'=>'Ghi chú: Trang chủ',
'LBL_SEARCH_FORM_TITLE'=>'Tìm ghi chú',
'LBL_LIST_FORM_TITLE'=>'Danh sách ghi chú',
'LBL_NEW_FORM_TITLE'=>'Ghi chú mới',

'LBL_LIST_SUBJECT'=>'Chủ đề',
'LBL_LIST_CONTACT_NAME'=>'Tên Liên hệ',
'LBL_LIST_RELATED_TO'=>'Liên quan tới',
'LBL_LIST_DATE_MODIFIED'=>'Ngày cập nhật gần nhất',

'LBL_NOTE'=>'Ghi chú',
'LBL_NOTE_SUBJECT'=>'Chủ đề',
'LBL_CONTACT_NAME'=>'Tên Liên hệ',
'LBL_PHONE'=>'Điện thoại',
'LBL_SUBJECT'=>'Chủ đề',
'LBL_CLOSE'=>'Kết thúc',
'LBL_RELATED_TO'=>'Liên quan tới',
'LBL_EMAIL_ADDRESS'=>'Địa chỉ Email',
'LBL_COLON'=>': ',

'ERR_DELETE_RECORD'=>"Số hiệu bản ghi cần được xác định để xóa Tài khoản.",
'LBL_LIST_FILENAME'=>"Tập tin",

// Added for Note(3.2-patch 3) 

'LBL_FILENAME'=>'Đính kèm',
'LBL_NOTE_INFORMATION'=>'Thông tin ghi chú',

// Added for 4GA
'LBL_TOOL_FORM_TITLE'=>'Ghi chú : Công cụ',
// Added for 4GA
'Contact Name'=>'Tên Liên hệ',
'Related To'=>'Liên quan tới',
'Subject'=>'Chủ đề',
'Created Time'=>'Ngày tạo',
'Modified Time'=>'Ngày cập nhật',
'Attachment'=>'Đính kèm',
'Note'=>'Ghi chú',
//Added for 4.2 Release -- CustomView
'Related to'=>'Liên quan tới',
'Last Modified'=>'Ngày cập nhật gần nhất',
'File'=>'Tập tin',
'LBL_ALL'=>'Tất cả',
'Title'=>'Tiêu đề',

);

?>
