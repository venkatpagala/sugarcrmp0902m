﻿<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
*
 ********************************************************************************/



$mod_strings = Array(
'LBL_CHARSET'=>'UTF-8',
'LBL_LOGIN'=>'Đăng nhập',
'LBL_USER_NAME'=>'Email đăng nhập:',
'LBL_PASSWORD'=>'Mật khẩu:',
'LNK_HOME'=>'Trang chủ',
'LNK_SUBMIT_NEW_TICKET'=>'Phiếu yêu cầu',
'LBL_WELCOME'=>'Chào mừng các bạn đến với cổng thông tin khách hàng',
'LNK_LOGOUT'=>'Thoát',
'LBL_MY_OPEN_TICKETS'=>'Các phiếu đang mở',
'LBL_CLOSED_TICKETS'=>'Các phiếu đã đóng',

'TICKETID'=>'Mã phiếu',
'TITLE'=>'Tiêu đề',
'PRIORITY'=>'Độ ưu tiên',
'STATUS'=>'Trạng thái',
'CATEGORY'=>'Mục lục',
'MODIFIED TIME'=>'Sửa lúc',
'CREATED TIME'=>'Tạo lúc',
'LBL_NONE_SUBMITTED'=>'Không có phiếu nào được gửi',
'LBL_CREATE_NEW_TICKET'=>'Tạo phiếu yêu cầu',

'LBL_NEW_INFORMATION'=>'Bạn hãy nhập vào các thông tin bắt buộc ở các trường bên dưới rồi bắt đầu gửi.',

'LBL_TITLE'=>'Tiêu đề',
'LBL_DESCRIPTION'=>'Mô tả',
'LBL_PRIORITY'=>'Độ ưu tiên',
	'LOW'=>'Thấp',
	'MEDIUM'=>'Trung bình',
	'HIGH'=>'Cao',
	'CRITICAL'=>'Quyết định',
'LBL_CATEGORY'=>'Mục lục',
	'BIG_PROBLEM'=>'Vấn đề lớn',
	'SMALL_PROBLEM'=>'Vấn đề nhỏ',
	'OTHER_PROBLEM'=>'Khác',
'LBL_SUBMIT'=>'Gửi',
'LBL_TICKET_ID'=>'Mã phiếu',
'LBL_STATUS'=>'Trạng thái',
'LBL_CREATED_TIME'=>'Tạo lúc',
'LBL_MODIFIED_TIME'=>'Sửa lúc',

//Added field after Beta Release
'LBL_CHANGE_PASSWORD'=>'Đổi mật khẩu',
'LBL_OLD_PASSWORD'=>'Mật khẩu cũ',
'LBL_NEW_PASSWORD'=>'Mật khẩu mới',
'LBL_CONFIRM_PASSWORD'=>'Xác nhận lại mật khẩu mới',

'MSG_PASSWORD_CHANGED'=>'Quá trình đổi mật khẩu diễn ra thành công.',
'MSG_ENTER_NEW_PASSWORDS_SAME'=>'Mật khẩu xác nhận không trùng khớp',
'MSG_YOUR_PASSWORD_WRONG'=>'Mật khẩu cũ sai.',
'LBL_RESOLUTION'=>'Giải pháp',
'LBL_MY_DETAILS'=>'Thông tin cá nhân',
'LBL_LAST_LOGIN'=>'Lần đăng nhập vừa qua',
'LBL_SUPPORT_START_DATE'=>'Ngày bắt đầu hỗ trợ',
'LBL_SUPPORT_END_DATE'=>'Ngày kết thúc hỗ trợ',
'LBL_PROFILE'=>'Hồ sơ cá nhân',
'LBL_TICKET_INFORMATION'=>'Thông tin phiếu',
'LBL_COMMENTS'=>'Bình luận',
'LBL_ADD_COMMENT'=>'Thêm bình luận',
'LBL_COMMENT_BY'=>'Bình luận bởi',
'LBL_ON'=>'bật',

//Added fields ater 4_2alpha release
'LBL_PRODUCT_NAME'=>'Tên sản phẩm ',
'LBL_SEVERITY'=>'Tính chất',
'LBL_FORGOT_LOGIN'=>'Bạn quên mật khẩu?',
'LBL_SIGN_UP'=>'Đăng ký?',
'LBL_YOUR_EMAIL'=>'Email của bạn là :',
'LBL_SEND_PASSWORD'=>'Gửi lại mật khẩu',
'LBL_CLOSE'=>'Đóng',
'LBL_CLOSE_TICKET'=>'Đóng phiếu này',

//Added fields for Knowledge Base details
'LBL_KNOWLEDGE_BASE'=>'Kiến thức cơ bản',
'LBL_SEARCH'=>'Tìm',
'LNK_CATEGORY'=>'Mục lục',
'LNK_PRODUCTS'=>'Sản phẩm',
'LBL_SEARCH_RESULT'=>'Kết quả tìm:',
'LBL_NO_FAQ_IN_THIS_CATEGORY'=>'Không có tin nào trong mục này.',
'LBL_NO_FAQ_IN_THIS_PRODUCT'=>'Không có tin nào trong sản phẩm này.',
'LBL_NO_FAQ'=>'Không có tin.',
'LBL_NO_FAQ_IN_THIS_SEARCH_CRITERIA'=>'Không có tin nào giống với mẫu tìm kiếm.',
'LBL_PRODUCT'=>'Sản phẩm',
'LBL_ADDED_ON'=>'Thêm vào : ',
'LBL_ARTICLE_ID'=>'Mã tin',
'LBL_PAGE_OPTIONS'=>'Tùy chọn trang',
'LBL_PRINT_THIS_PAGE'=>'In ra trang này',
'LBL_EMAIL_THIS_PAGE'=>'Gửi email trang này',
'LBL_ADD_TO_FAVORITES'=>'Thêm vào ưa thích',
'LBL_RECENTLY_CREATED'=>'Các tin tạo gần đây',
'LBL_CREATED_DATE'=>'Ngày tạo',
'LBL_MODIFIED_DATE'=>'Ngày sửa',
'LNK_CUSTOMER_PORTAL_LOGIN'=>'Đăng nhập cổng người dùng',
'KBASE_DETAILS'=>'The knowledge base is organized based on both categories and products, please select a category or product that you are interested in.
Additionally, you can also search the entire knowledge base by entering keywords below.',

//Added after 4.2GA patch1
'LBL_STATUS_CLOSED'=>'Closed',//Do not convert this label. This is used to check the status. If the status 'Closed' is changed in vtigerCRM server side then you will give the exact value of status 'Closed' which is in vtigerCRM server.

//Added to display the module -- 10-11-2005
'LBL_MODULE'=>'Phân hệ',
'LBL_NO_DETAILS_EXIST'=>'Không có chi tiết nào tồn tại cho mã phiếu này.',
'LBL_LOGIN_NOTE'=>'Email đăng nhập và mật khẩu phân biệt chữ hoa và chữ thường.',

);







?>
