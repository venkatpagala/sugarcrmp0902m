<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
*
 ********************************************************************************/


session_start();
/** Function to  return a string with backslashes stripped off
 * @param $value -- value:: Type string
 * @returns $value -- value:: Type string array
 */
function stripslashes_checkstrings($value){
        if(is_string($value)){
                return stripslashes($value);
        }
        return $value;
}

if(get_magic_quotes_gpc() == 1){
        $_REQUEST = array_map("stripslashes_checkstrings", $_REQUEST);
        $_POST = array_map("stripslashes_checkstrings", $_POST);
        $_GET = array_map("stripslashes_checkstrings", $_GET);
}

include("include.php");
include("version.php");

if($_REQUEST['param'] == 'forgot_password')
{
	global $client;

	$email = $_REQUEST['email_id'];
	$params = array('email' => "$email");
	$result = $client->call('send_mail_for_password', $params);
	$_REQUEST['mail_send_message'] = $result;
	require_once("supportpage.php");
}
elseif($_REQUEST['logout'] == 'true')
{
	$customerid = $_SESSION['customer_id'];
	$sessionid = $_SESSION['customer_sessionid'];

	$params = Array(Array('id' => "$customerid", 'sessionid'=>"$sessionid", 'flag'=>"logout"));
        $result = $client->call('update_login_details', $params);

	session_unregister('customer_id');
	session_unregister('customer_name');
	session_unregister('last_login');
	session_unregister('support_start_date');
	session_unregister('support_end_date');
	//session_destroy();
	//include("index.php");
	include("login.php");
}
else
{
	$module = '';
	$action = 'login.php';
	if($_SESSION['customer_id'] != '')
	{
		$is_logged = 1;

		//Added to download attachments
		if($_REQUEST['downloadfile'] == 'true')
		{
			$filename = $_REQUEST['filename'];
			$fileType = $_REQUEST['filetype'];
			$fileid = $_REQUEST['fileid'];
			$filesize = $_REQUEST['filesize'];

			//we have to get the content by passing the customerid, fileid and filename
			$customerid = $_SESSION['customer_id'];
			$sessionid = $_SESSION['customer_sessionid'];
		
			$params = Array(Array('id'=>"$customerid", 'sessionid'=>"$sessionid", 'fileid'=>$fileid, 'filename'=>$filename));
			$fileContent = $client->call('get_filecontent', $params, $Server_Path, $Server_Path);

			header("Content-type: $fileType");
			header("Content-length: $filesize");
			header("Cache-Control: private");
			header("Content-Disposition: attachment; filename=$filename");
			header("Content-Description: PHP Generated Data");
			echo base64_decode($fileContent[0]);
			exit;
		}
		if($_REQUEST['module'] != '' && $_REQUEST['action'] != '')
		{
			$module = $_REQUEST['module']."/";
			$action = $_REQUEST['action'].".php";
		}
		elseif($_REQUEST['action'] != '' && $_REQUEST['module'] == '')
		{
			$action = $_REQUEST['action'].".php";
		}
		elseif($_SESSION['customer_id'] != '')
		{
			$module = 'Tickets';
			//$action = "TicketsList.php";
			$action = "index.php";
		}
	}
	$filename = $module.$action;

	if($is_logged == 1)
	{
		include("Tickets/Utils.php");
		include("language/vn.lang.php");
		global $default_charset;
		header('Content-Type: text/html; charset='.$default_charset);
		include("header.html");

	?>

	<script>
		<?php
		//highlight the selected tab
		$tabArray = Array("Tickets","Faq");
		foreach($tabArray as $tabName)
		{
			if(strcmp(rtrim($module,"/"),$tabName) == 0)//strstr($module,$tabName))
			{
			?>
				document.getElementById("<?php echo $tabName;?>").className = "dvtSelectedCell";
			<?php
			}
			else
			{
			?>
				document.getElementById("<?php echo $tabName;?>").className = "dvtUnSelectedCell";
			<?php
			}
		}
		?>
	</script>

	<?php

		if(is_file($filename))
			include($filename);
		elseif($_SESSION['customer_id'] != '')
			include("Tickets/index.php");

		include("footer.html");
	}
	else
		header("Location: login.php");

}

?>
