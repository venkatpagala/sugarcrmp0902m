// JavaScript Document

function fnLoadValues(obj){

	/*
	var tabArray = Array("Tickets","Faq");

	for(var i=0;i<2;i++)
	{
		if(tabArray[i].indexOf(obj) > -1)
			document.getElementById(tabArray[i]).className = "dvtSelectedCell";
		else
			document.getElementById(tabArray[i]).className = "dvtUnSelectedCell";
	}
	*/
	window.location.href = "index.php?module="+obj+"&action=index";
}

function fnDown(obj){
	var tagName = document.getElementById(obj);
	if(tagName.style.display == 'block')
		tagName.style.display = 'none';
	else
		tagName.style.display = 'block';
}

function fnShowDiv(obj){
	var tagName = document.getElementById(obj);
		tagName.style.visibility = 'visible';
}


function fnHideDiv(obj){
	var tagName = document.getElementById(obj);
		tagName.style.visibility = 'hidden';
}

function findPosX(obj) {
	var curleft = 0;
	if (document.getElementById || document.all) {
		while (obj.offsetParent) {
			curleft += obj.offsetLeft
			obj = obj.offsetParent;
		}
	} 
	else if (document.layers) {curleft += obj.x;}
	return curleft;
}

function findPosY(obj) {
	var curtop = 0;
	if (document.getElementById || document.all) {
		while (obj.offsetParent) {
			curtop += obj.offsetTop
			obj = obj.offsetParent;
		}
	}
	else if (document.layers) {curtop += obj.y;}
	return curtop;
}

function fnShow(obj){
	var tagName = document.getElementById('faqDetail');
	var leftSide = findPosX(obj);
	var topSide = findPosY(obj);
		topSide = topSide - 90;
		leftSide = leftSide - 200; 
		tagName.style.top = topSide + 'px';
		tagName.style.left = leftSide + 'px';
		tagName.style.visibility = 'visible';
}

function trim(s) 
{
	while (s.substring(0,1) == " ")
	{
		s = s.substring(1, s.length);
	}
	while (s.substring(s.length-1, s.length) == ' ')
	{
		s = s.substring(0,s.length-1);
	}

	return s;
}


