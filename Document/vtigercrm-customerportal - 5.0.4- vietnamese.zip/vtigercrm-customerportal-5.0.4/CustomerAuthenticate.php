<?php
/*********************************************************************************
 ** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *
 ********************************************************************************/

include("include.php");

$username = trim($_REQUEST['username']);
$password = trim($_REQUEST['pw']);

//$encrypted_password = encrypt_password($username,$password);

$params = array('user_name' => "$username",
	'user_password'=>"$password");

global $result;
$result = $client->call('authenticate_user', $params, $Server_Path, $Server_Path);

//The following are the debug informations
$err = $client->getError();
if ($err)
{
	//Uncomment the following lines to get the error message in login screen itself.
	/*
	echo '<h2>Error Message</h2><pre>' . $err . '</pre>';
	echo '<h2>request</h2><pre>' . htmlspecialchars($client->request, ENT_QUOTES) . '</pre>';
	echo '<h2>response</h2><pre>' . htmlspecialchars($client->response, ENT_QUOTES) . '</pre>';
	echo '<h2>debug</h2><pre>' . htmlspecialchars($client->debug_str, ENT_QUOTES) . '</pre>';
	exit;
	*/
	$login_error_msg = "Could not connect to server. Please contact the administrator.";
	$login_error_msg = base64_encode('<font color=red size=1px;> '.$login_error_msg.' </font>');
	header("Location: login.php?login_error=$login_error_msg");
	exit;
}
//$curdate=date("Y n d");
//$ed=str_replace('-',' ',$result[5]);
//$end_date=date($ed);
//$sd=str_replace('-',' ',$result[4]);
//$start_date=date($sd);

if(strtolower($result[0]['user_name']) == strtolower($username) && strtolower($result[0]['user_password']) == strtolower($password))
{
	session_start();
	$_SESSION['customer_id'] = $result[0]['id'];
	$_SESSION['customer_sessionid'] = $result[0]['sessionid'];
	$_SESSION['customer_name'] = $result[0]['user_name'];
	$_SESSION['last_login'] = $result[0]['last_login_time'];
	$_SESSION['support_start_date'] = $result[0]['support_start_date'];
	$_SESSION['support_end_date'] = $result[0]['support_end_date'];

	$customerid = $_SESSION['customer_id'];
	$sessionid = $_SESSION['customer_sessionid'];

	$params1 = Array(Array('id' => "$customerid", 'sessionid'=>"$sessionid", 'flag'=>"login"));

	$result2 = $client->call('update_login_details', $params1, $Server_Path, $Server_Path);

	//include("general.php");
	header("Location: index.php?action=index&module=Tickets");
}
else
{
	if($result[0] != '')
			$error_msg = $result[0];
	else
			$error_msg = "Could not login. Please contact administrator";

	$login_error_msg = base64_encode('<font color=red size=1px;> '.$error_msg.' </font>');
	header("Location: login.php?login_error=$login_error_msg");
}
/*
function encrypt_password($user_name,$user_password)
{
	// encrypt the password.
	$salt = substr($user_name, 0, 2);
	$encrypted_password = crypt($user_password, $salt);

	return $encrypted_password;
}
 */
?>
