<?php
$module_name = 'HRM_Holidays';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'HOL_MOIS' => 
  array (
    'width' => '10%',
    'label' => 'LBL_HOL_MOIS',
    'default' => true,
  ),
  'HOL_YEAR' => 
  array (
    'width' => '10%',
    'label' => 'LBL_HOL_YEAR',
    'default' => true,
  ),
  'HOL_TYPE' => 
  array (
    'width' => '10%',
    'label' => 'LBL_HOL_TYPE',
    'default' => true,
  ),
  'HRM_EMPLOYEES_HRM_HOLYDAYS_NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_EMPLOYEE',
    'default' => true,
    'link' => true,
    'module' => 'HRM_Employees',
    'id' => 'HRM_EMPLOYE_EMPLOYEES_IDA',
  ),
);
?>
