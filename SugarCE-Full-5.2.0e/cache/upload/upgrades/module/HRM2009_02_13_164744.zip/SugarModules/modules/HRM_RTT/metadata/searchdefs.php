<?php
$module_name = 'HRM_RTT';
$searchdefs [$module_name] = 
array (
  'layout' => 
  array (
    'basic_search' => 
    array (
      'rtt_mois' => 
      array (
        'width' => '10%',
        'label' => 'LBL_RTT_MOIS',
        'default' => true,
        'name' => 'rtt_mois',
      ),
      'rtt_year' => 
      array (
        'width' => '10%',
        'label' => 'LBL_RTT_YEAR',
        'default' => true,
        'name' => 'rtt_year',
      ),
    ),
    'advanced_search' => 
    array (
      'rtt_mois' => 
      array (
        'width' => '10%',
        'label' => 'LBL_RTT_MOIS',
        'default' => true,
        'name' => 'rtt_mois',
      ),
      'rtt_year' => 
      array (
        'width' => '10%',
        'label' => 'LBL_RTT_YEAR',
        'default' => true,
        'name' => 'rtt_year',
      ),
      'rtt_type' => 
      array (
        'width' => '10%',
        'label' => 'LBL_RTT_TYPE',
        'default' => true,
        'name' => 'rtt_type',
      ),
    ),
  ),
  'templateMeta' => 
  array (
    'maxColumns' => '3',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
);
?>
