<?php
// created: 2009-01-20 10:46:09
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 10:46:09
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-20 10:46:09
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:15:34
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:15:34
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-20 11:15:34
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:19:01
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:19:01
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-20 11:19:01
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:22:02
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:22:02
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-20 11:22:02
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:22:18
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:22:18
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-20 11:22:18
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:22:22
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:22:22
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-20 11:22:22
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-23 15:37:57
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-23 15:37:57
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-23 15:37:57
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-23 15:38:18
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-23 15:38:18
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-23 15:38:18
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-29 10:35:17
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-29 10:35:17
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-29 10:35:17
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-29 10:41:12
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-29 10:41:12
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-29 10:41:12
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-29 10:46:01
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-29 10:46:01
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-29 10:46:01
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-02 15:40:02
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-02 15:40:02
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-02 15:40:02
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-02 15:40:32
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-02 15:40:32
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-02 15:40:32
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-02 15:41:43
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-02 15:41:43
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-02 15:41:43
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:10:07
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:10:08
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 11:10:08
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:13:05
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:13:05
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 11:13:05
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:23:45
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:23:45
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 11:23:45
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:24:51
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:24:51
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 11:24:51
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:26:15
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:26:15
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 15:26:15
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:41:28
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:41:28
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 15:41:28
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:41:50
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:41:50
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 15:41:50
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:53:12
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:53:12
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 15:53:12
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:53:28
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:53:28
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 15:53:28
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 09:47:07
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 09:47:07
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 09:47:07
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:03:24
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:03:24
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 10:03:24
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:04:57
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:04:57
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 10:04:57
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:07:31
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:07:31
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 10:07:31
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:27:20
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:27:20
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 10:27:20
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:32:46
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:32:46
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 10:32:46
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:39:39
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:39:39
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 10:39:39
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 11:51:56
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 11:51:56
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 11:51:56
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 11:52:47
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 11:52:47
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 11:52:47
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:07:41
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:07:41
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 12:07:41
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:08:15
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:08:15
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 12:08:15
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:19:30
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:19:30
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 12:19:30
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:20:09
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:20:09
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 12:20:09
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:20:38
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:20:38
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 12:20:38
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 14:15:36
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 14:15:36
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 14:15:36
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 14:16:04
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 14:16:04
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 14:16:04
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-09 17:35:56
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-09 17:35:56
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-09 17:35:56
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-09 17:37:03
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-09 17:37:03
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-09 17:37:03
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:07:54
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:07:54
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 10:07:54
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:48:27
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:48:27
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 10:48:27
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:58:53
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:58:53
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 10:58:53
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:59:56
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:59:56
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 10:59:56
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:00:47
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:00:47
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:00:47
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:04:39
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:04:39
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:04:39
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:04:54
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:04:54
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:04:54
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:05:22
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:05:22
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:05:22
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:07:08
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:07:08
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:07:08
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:09:05
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:09:05
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:09:05
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:22:42
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:22:42
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:22:42
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:34:59
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:34:59
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:34:59
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:53:18
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:53:18
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:53:18
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:54:07
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:54:07
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:54:07
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:16:08
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:16:08
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 12:16:08
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:16:45
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:16:45
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 12:16:45
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:19:23
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:19:23
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 12:19:23
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:19:44
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:19:44
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 12:19:44
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:17:40
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:17:40
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:17:40
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:21:55
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:21:55
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:21:55
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:23:18
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:23:18
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:23:18
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:36:50
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:36:50
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:36:50
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:38:23
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:38:23
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:38:23
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:39:31
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:39:31
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:39:31
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:41:53
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:41:53
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:41:53
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:30:35
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:30:35
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 16:30:35
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:39:44
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:39:44
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 16:39:44
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:40:19
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:40:19
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 16:40:19
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:47:15
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:47:15
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 16:47:15
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:47:42
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto"] = array (
  'name' => 'hrm_employees_hrm_ticketresto',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:47:42
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employees_hrm_ticketresto_name"] = array (
  'name' => 'hrm_employees_hrm_ticketresto_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_TICKETRESTO_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_ticketresto',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 16:47:42
$dictionary["HRM_Ticketresto"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_ticketresto',
  'source' => 'non-db',
);
?>
