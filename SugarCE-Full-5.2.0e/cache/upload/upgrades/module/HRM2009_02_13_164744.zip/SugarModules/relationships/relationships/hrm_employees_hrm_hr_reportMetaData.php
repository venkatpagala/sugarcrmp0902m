<?php
// created: 2009-02-13 11:05:20
$dictionary["hrm_employees_hrm_hr_report"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'hrm_employees_hrm_hr_report' => 
    array (
      'lhs_module' => 'HRM_Employees',
      'lhs_table' => 'hrm_employees',
      'lhs_key' => 'id',
      'rhs_module' => 'HRM_HR_Report',
      'rhs_table' => 'hrm_hr_report',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'hrm_employerm_hr_report_c',
      'join_key_lhs' => 'hrm_employe_employees_ida',
      'join_key_rhs' => 'hrm_employe_hr_report_idb',
    ),
  ),
  'table' => 'hrm_employerm_hr_report_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'hrm_employe_employees_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'hrm_employe_hr_report_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'hrm_employe_hrm_hr_reportspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'hrm_employe_hrm_hr_report_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'hrm_employe_employees_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'hrm_employe_hrm_hr_report_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'hrm_employe_hr_report_idb',
      ),
    ),
  ),
);
?>
