<?php
// created: 2008-12-13 17:03:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-13 17:03:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-13 17:03:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-13 17:10:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-13 17:10:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-13 17:10:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-13 18:16:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-13 18:16:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-13 18:16:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-14 12:02:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-14 12:02:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-14 12:02:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 12:11:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 12:11:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-15 12:11:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 12:13:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 12:13:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-15 12:13:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 12:16:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 12:16:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-15 12:16:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 12:22:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 12:22:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-15 12:22:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 13:55:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 13:55:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-15 13:55:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 17:35:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 17:35:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-15 17:35:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 18:00:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 18:00:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-15 18:00:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 18:04:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 18:04:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-15 18:04:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 18:23:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-15 18:23:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-15 18:23:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:18:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:18:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 12:18:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:22:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:22:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 12:22:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:23:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:23:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 12:23:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:27:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:27:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 12:27:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:27:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:27:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 12:27:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:28:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:28:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 12:28:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:31:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:31:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 12:31:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:33:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:33:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 12:33:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:34:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:34:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 12:34:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:35:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:35:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 12:35:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:38:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:38:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 12:38:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:39:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 12:39:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 12:39:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 15:18:31
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 15:18:31
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 15:18:31
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 15:25:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 15:25:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 15:25:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 15:51:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 15:51:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 15:51:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 15:52:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-16 15:52:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-16 15:52:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 10:06:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 10:06:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 10:06:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 10:13:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 10:13:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 10:13:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 10:15:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 10:15:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 10:15:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 10:17:19
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 10:17:19
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 10:17:19
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 10:19:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 10:19:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 10:19:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 11:22:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 11:22:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 11:22:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 11:25:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 11:25:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 11:25:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:19:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:19:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 15:19:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:28:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:28:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 15:28:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:33:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:33:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 15:33:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:36:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:36:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 15:36:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:38:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:38:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 15:38:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:39:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:39:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 15:39:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:39:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 15:39:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 15:39:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:21:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:21:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 16:21:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:24:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:24:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 16:24:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:27:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:27:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 16:27:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:28:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:28:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 16:28:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:29:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:29:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 16:29:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:30:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:30:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 16:30:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:32:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:32:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 16:32:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:35:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:35:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 16:35:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:36:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:36:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 16:36:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:37:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:37:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 16:37:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:44:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:44:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 16:44:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:52:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 16:52:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 16:52:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:02:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:02:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:02:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:06:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:06:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:06:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:07:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:07:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:07:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:08:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:08:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:08:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:15:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:15:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:15:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:24:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:24:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:24:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:25:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:25:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:25:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:34:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:34:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:34:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:47:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:47:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:47:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:48:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:48:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:48:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:48:58
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:48:58
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:48:58
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:49:12
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:49:12
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:49:12
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:49:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:49:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:49:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:52:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:52:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:52:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:53:20
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:53:20
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:53:20
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:53:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:53:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:53:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:55:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:55:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:55:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:57:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:57:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:57:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:57:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:57:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:57:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:58:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 17:58:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 17:58:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:00:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:00:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:00:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:01:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:01:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:01:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:02:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:02:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:02:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:03:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:03:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:03:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:03:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:03:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:03:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:06:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:06:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:06:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:07:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:07:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:07:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:08:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:08:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:08:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:10:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:10:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:10:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:12:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:12:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:12:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:14:19
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:14:19
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:14:19
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:15:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:15:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:15:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:16:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:16:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:16:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:18:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:18:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:18:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:24:03
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:24:03
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:24:03
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:25:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:25:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:25:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:26:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:26:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:26:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:28:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:28:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:28:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:32:51
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:32:51
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:32:51
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:35:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:35:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:35:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:35:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-17 18:35:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-17 18:35:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-18 11:11:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-18 11:11:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-18 11:11:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-18 11:36:12
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-18 11:36:12
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-18 11:36:12
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-18 11:39:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-18 11:39:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-18 11:39:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 15:20:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 15:20:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 15:20:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 15:28:20
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 15:28:20
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 15:28:20
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 15:32:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 15:32:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 15:32:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 15:34:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 15:34:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 15:34:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 15:36:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 15:36:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 15:36:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 15:48:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 15:48:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 15:48:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 16:40:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 16:40:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 16:40:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 17:33:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 17:33:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 17:33:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 17:45:51
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 17:45:51
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 17:45:51
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 17:48:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 17:48:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 17:48:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 17:51:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 17:51:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 17:51:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 17:59:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 17:59:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 17:59:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:00:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:00:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 18:00:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:05:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:05:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 18:05:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:08:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:08:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 18:08:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:13:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:13:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 18:13:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:16:58
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:16:58
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 18:16:58
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:18:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:18:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 18:18:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:20:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:20:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 18:20:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:25:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:25:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 18:25:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:26:50
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:26:50
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 18:26:50
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:48:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:48:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 18:48:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:55:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2008-12-20 18:55:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2008-12-20 18:55:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 10:57:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 10:57:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 10:57:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 11:12:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 11:12:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 11:12:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 11:17:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 11:17:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 11:17:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 11:45:54
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 11:45:54
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 11:45:54
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 11:46:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 11:46:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 11:46:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 11:53:20
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 11:53:20
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 11:53:20
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 11:58:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 11:58:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 11:58:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 12:09:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 12:09:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 12:09:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 12:10:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 12:10:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 12:10:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 12:17:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 12:17:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 12:17:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 13:44:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 13:44:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 13:44:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 16:20:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 16:20:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 16:20:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 16:21:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 16:21:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 16:21:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 17:25:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 17:25:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 17:25:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 17:25:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 17:25:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 17:25:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 17:26:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 17:26:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 17:26:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 17:35:54
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-05 17:35:54
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-05 17:35:54
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:21:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:21:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 10:21:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:26:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:26:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 10:26:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:37:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:37:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 10:37:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:49:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:49:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 10:49:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:50:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:50:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 10:50:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:50:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:50:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 10:50:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:53:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:53:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 10:53:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:57:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:57:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 10:57:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:58:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:58:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 10:58:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:59:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 10:59:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 10:59:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:03:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:03:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 11:03:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:12:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:12:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 11:12:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:13:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:13:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 11:13:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:15:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:15:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 11:15:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:17:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:17:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 11:17:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:19:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:19:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 11:19:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:57:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:57:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 11:57:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:59:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 11:59:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 11:59:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:07:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:07:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 12:07:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:08:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:08:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 12:08:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:10:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:10:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 12:10:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:14:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:14:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 12:14:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:17:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:17:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 12:17:25
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:25:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:25:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 12:25:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:29:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:29:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 12:29:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:30:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:30:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 12:30:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:33:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:33:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 12:33:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:36:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:36:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 12:36:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:37:50
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 12:37:50
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 12:37:50
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 15:21:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 15:21:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 15:21:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 15:22:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 15:22:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 15:22:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 15:23:59
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 15:23:59
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 15:23:59
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 15:37:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 15:37:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 15:37:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 15:47:31
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 15:47:31
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 15:47:31
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 15:59:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 15:59:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 15:59:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 16:10:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 16:10:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 16:10:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 16:27:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 16:27:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 16:27:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:00:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:00:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:00:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:00:31
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:00:31
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:00:31
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:22:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:22:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:22:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:23:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:23:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:23:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:27:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:27:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:27:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:27:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:27:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:27:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:27:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:27:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:27:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:48:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:48:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:48:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:51:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:51:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:51:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:52:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:52:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:52:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:53:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:53:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:53:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:53:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:53:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:53:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:54:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:54:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:54:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:54:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-06 17:54:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-06 17:54:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 11:04:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 11:04:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 11:04:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 11:22:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 11:22:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 11:22:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 11:54:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 11:54:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 11:54:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 12:01:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 12:01:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 12:01:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 12:13:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 12:13:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 12:13:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 12:15:34
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 12:15:34
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 12:15:34
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 12:19:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 12:19:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 12:19:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 12:25:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 12:25:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 12:25:53
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 15:56:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 15:56:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 15:56:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:00:51
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:00:51
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 16:00:51
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:03:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:03:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 16:03:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:55:01
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:55:01
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 16:55:01
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:55:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:55:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 16:55:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:58:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:58:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 16:58:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:58:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:58:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 16:58:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:58:34
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:58:34
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 16:58:34
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:58:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:58:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 16:58:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:58:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 16:58:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 16:58:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:00:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:00:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:00:15
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:02:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:02:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:02:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:28:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:28:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:28:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:30:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:30:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:30:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:32:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:32:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:32:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:33:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:33:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:33:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:37:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:37:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:37:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:38:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:38:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:38:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:39:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:39:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:39:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:40:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:40:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:40:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:41:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:41:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:41:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:42:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:42:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:42:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:46:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:46:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:46:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:46:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:46:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:46:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:46:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:46:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:46:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:52:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:52:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:52:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:55:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 17:55:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 17:55:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 18:00:34
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 18:00:34
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 18:00:34
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 18:03:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 18:03:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 18:03:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 18:09:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 18:09:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 18:09:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 18:11:50
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 18:11:50
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 18:11:50
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 18:20:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-12 18:20:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-12 18:20:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 10:45:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 10:45:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 10:45:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 10:52:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 10:52:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 10:52:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 10:52:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 10:52:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 10:52:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 11:54:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 11:54:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 11:54:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 12:02:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 12:02:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 12:02:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 12:04:20
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 12:04:20
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 12:04:20
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 16:45:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 16:45:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 16:45:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 16:46:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 16:46:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 16:46:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 16:47:42
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 16:47:42
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 16:47:42
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 16:51:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 16:51:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 16:51:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 16:52:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 16:52:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 16:52:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 16:58:59
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 16:58:59
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 16:58:59
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 17:07:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 17:07:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 17:07:05
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 17:38:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 17:38:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 17:38:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 17:39:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 17:39:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 17:39:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 17:42:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 17:42:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 17:42:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 17:55:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-13 17:55:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-13 17:55:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:16:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:16:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:16:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:19:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:19:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:19:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:28:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:28:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:28:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:30:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:30:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:30:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:32:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:32:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:32:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:34:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:34:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:34:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:37:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:37:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:37:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:40:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:40:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:40:13
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:42:51
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:42:51
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:42:51
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:48:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:48:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:48:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:49:18
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:49:18
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:49:18
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:52:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:52:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:52:48
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:54:18
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:54:18
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:54:18
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:58:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 10:58:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 10:58:10
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:03:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:03:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:03:09
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:09:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:09:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:09:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:11:03
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:11:03
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:11:03
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:29:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:29:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:29:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:31:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:31:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:31:26
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:34:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:34:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:34:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:35:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:35:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:35:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:38:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:38:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:38:24
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:38:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:38:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:38:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:47:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:47:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:47:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:47:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:47:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:47:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:48:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:48:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:48:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:49:01
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 11:49:01
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 11:49:01
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 13:52:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-14 13:52:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-14 13:52:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 10:46:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 10:46:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-20 10:46:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:15:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:15:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-20 11:15:33
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:19:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:19:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-20 11:19:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:22:01
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:22:01
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-20 11:22:01
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:22:18
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:22:18
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-20 11:22:18
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:22:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-20 11:22:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-20 11:22:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-23 15:37:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-23 15:37:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-23 15:37:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-23 15:38:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-23 15:38:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-23 15:38:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-29 10:35:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-29 10:35:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-29 10:35:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-29 10:41:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-29 10:41:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-29 10:41:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-29 10:46:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-01-29 10:46:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-01-29 10:46:00
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-02 15:40:01
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-02 15:40:01
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-02 15:40:01
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-02 15:40:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-02 15:40:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-02 15:40:32
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-02 15:41:42
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-02 15:41:42
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-02 15:41:42
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:10:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:10:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 11:10:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:13:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:13:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 11:13:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:23:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:23:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 11:23:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:24:50
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 11:24:50
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 11:24:50
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:26:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:26:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 15:26:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:41:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:41:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 15:41:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:41:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:41:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 15:41:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:53:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:53:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 15:53:11
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:53:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-03 15:53:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-03 15:53:28
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 09:47:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 09:47:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 09:47:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:03:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:03:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 10:03:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:04:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:04:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 10:04:56
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:07:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:07:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 10:07:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:27:19
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:27:19
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 10:27:19
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:32:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:32:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 10:32:45
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:39:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 10:39:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 10:39:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 11:51:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 11:51:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 11:51:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 11:52:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 11:52:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 11:52:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:07:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:07:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 12:07:40
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:08:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:08:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 12:08:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:19:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:19:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 12:19:29
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:20:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:20:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 12:20:08
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:20:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 12:20:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 12:20:37
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 14:15:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 14:15:35
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 14:15:36
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 14:16:03
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-04 14:16:03
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-04 14:16:03
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-09 17:35:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-09 17:35:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-09 17:35:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-09 17:37:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-09 17:37:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-09 17:37:02
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:07:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:07:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 10:07:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:48:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:48:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 10:48:27
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:58:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:58:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 10:58:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:59:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 10:59:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 10:59:55
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:00:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:00:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:00:46
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:04:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:04:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:04:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:04:54
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:04:54
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:04:54
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:05:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:05:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:05:21
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:07:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:07:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:07:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:09:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:09:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:09:04
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:22:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:22:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:22:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:34:57
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:34:58
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:34:58
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:53:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:53:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:53:17
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:54:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 11:54:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 11:54:06
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:16:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:16:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 12:16:07
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:16:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:16:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 12:16:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:19:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:19:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 12:19:23
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:19:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 12:19:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 12:19:43
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:17:38
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:17:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:17:39
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:21:54
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:21:54
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:21:54
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:23:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:23:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:23:16
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:36:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:36:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:36:49
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:38:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:38:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:38:22
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:39:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:39:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:39:30
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:41:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 14:41:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 14:41:52
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:30:34
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:30:34
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 16:30:34
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:39:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:39:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 16:39:44
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:40:18
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:40:18
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 16:40:18
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:47:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:47:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 16:47:14
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:47:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus"] = array (
  'name' => 'hrm_employees_hrm_bonus',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
<?php
// created: 2009-02-13 16:47:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employees_hrm_bonus_name"] = array (
  'name' => 'hrm_employees_hrm_bonus_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_HRM_EMPLOYEES_HRM_BONUS_FROM_HRM_EMPLOYEES_TITLE',
  'save' => true,
  'id_name' => 'hrm_employe_employees_ida',
  'link' => 'hrm_employees_hrm_bonus',
  'table' => 'hrm_employees',
  'module' => 'HRM_Employees',
  'rname' => 'name',
);
?>
<?php
// created: 2009-02-13 16:47:41
$dictionary["HRM_Bonus"]["fields"]["hrm_employe_employees_ida"] = array (
  'name' => 'hrm_employe_employees_ida',
  'type' => 'link',
  'relationship' => 'hrm_employees_hrm_bonus',
  'source' => 'non-db',
);
?>
